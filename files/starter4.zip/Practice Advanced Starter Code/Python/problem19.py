def goldbach(n):
    # Replace None with your answer.
    return None

print(goldbach(8))
print(goldbach(4))
print(goldbach(10))