def encrypt(input):
    # Replace None with your answer.
    return None

print(encrypt("coding"))
print(encrypt("python"))
print(encrypt("string"))
print(encrypt("i like pie"))