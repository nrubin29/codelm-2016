def are_anagrams(a, b):
    # Replace None with your answer.
    return None

print(are_anagrams("cinema", "iceman"))
print(are_anagrams("one", "two"))
print(are_anagrams("dormitory", "dirty room"))