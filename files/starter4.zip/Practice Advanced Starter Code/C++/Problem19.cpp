#include <iostream>

using namespace std;

int main() {
	cout << goldbach(8) << endl;
	cout << goldbach(4) << endl;
	cout << goldbach(10) << endl;
}
	
string goldbach(int n) {
	// Replace empty string with your answer.
	return "";
}
