#include <iostream>

using namespace std;

int main() {
	cout << areAnagrams("cinema", "iceman") << endl;
	cout << areAnagrams("one", "two") << endl;
	cout << areAnagrams("dormitory", "dirty room") << endl;
}
	
bool areAnagrams(string a, string b) {
	// Replace false with your answer.
	return false;
}
