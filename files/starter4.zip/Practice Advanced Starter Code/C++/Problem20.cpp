#include <iostream>

using namespace std;

int main() {
	cout << encrypt("coding") << endl;
	cout << encrypt("python") << endl;
	cout << encrypt("string") << endl;
	cout << encrypt("i like pie") << endl;
}
	
string encrypt(string input) {
	// Replace empty string with your answer.
	return "";
}
