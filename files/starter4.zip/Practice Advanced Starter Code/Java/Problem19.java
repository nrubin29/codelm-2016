public class Problem19 {

	public static void main(String[] args) {
		System.out.println(goldbach(8));
		System.out.println(goldbach(4));
		System.out.println(goldbach(10));
	}
	
	public static String goldbach(int n) {
		// Replace null with your answer.
		return null;
	}
}