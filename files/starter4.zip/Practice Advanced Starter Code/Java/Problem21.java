public class Problem21 {

	public static void main(String[] args) {
		System.out.println(areAnagrams("cinema", "iceman"));
		System.out.println(areAnagrams("one", "two"));
		System.out.println(areAnagrams("dormitory", "dirty room"));
	}
	
	public static boolean areAnagrams(String a, String b) {
		// Replace false with your answer.
		return false;
	}
}