def get_max_value(roll):
	# Replace 0 with your answer.
	return 0

print(get_max_value([6, 2, 6, 6, 2]))  # Should be 25
print(get_max_value([1, 4, 6, 4, 1]))  # Should be 8
print(get_max_value([1, 2, 4, 3, 2]))  # Should be 30
print(get_max_value([1, 1, 1, 1, 1]))  # Should be 50
print(get_max_value([2, 2, 5, 3, 1]))  # Should be 5