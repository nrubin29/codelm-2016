def get_summations(n):
	# Replace None with your answer.
	return None

# See the packet for correct answers.
print(getSummations(5))
print(getSummations(8))
print(getSummations(12))