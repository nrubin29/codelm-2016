def print_hourglass(n):
	# This problem does not have a return statement. You will use System.out.println().
	pass

# See the packet for correct answers.
print_hourglass(1)
print_hourglass(2)
print_hourglass(3)
print_hourglass(5)
print_hourglass(10)