public class Problem3 {

	public static void main(String[] args) {
		System.out.println(getMaxValue(new int[] {6, 2, 6, 6, 2})); // Should be 25
		System.out.println(getMaxValue(new int[] {1, 4, 6, 4, 1})); // Should be 8
		System.out.println(getMaxValue(new int[] {1, 2, 4, 3, 2})); // Should be 30
		System.out.println(getMaxValue(new int[] {1, 1, 1, 1, 1})); // Should be 50
		System.out.println(getMaxValue(new int[] {2, 2, 5, 3, 1})); // Should be 5
	}
	
	public static int getMaxValue(int[] roll) {
		// Replace 0 with your answer.
		return 0;
	}
}