public class Problem1 {

	public static void main(String[] args) {
		// See the packet for correct answers.
		printHourglass(1);
		printHourglass(2);
		printHourglass(3);
		printHourglass(5);
		printHourglass(10);
	}
	
	public static void printHourglass(int n) {
		// This problem does not have a return statement. You will use System.out.println().
	}
}