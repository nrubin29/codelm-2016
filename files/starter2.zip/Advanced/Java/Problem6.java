import java.util.ArrayList;

public class Problem6 {

	public static void main(String[] args) {
		// See the packet for correct answers.
		System.out.println(getSummations(5));
		System.out.println(getSummations(8));
		System.out.println(getSummations(12));
	}
	
	public static ArrayList<String> getSummations(int n) {
		// Replace null with your answer.
		return null;
	}
}