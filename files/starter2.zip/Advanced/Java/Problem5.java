import java.util.ArrayList;

public class Problem5 {

	public static void main(String[] args) {
		// See the packet for correct answers.
		System.out.println(getPossibleBarcodes("|:|_: ||_:: |_:_| ||_:_ :|__|"));
		System.out.println(getPossibleBarcodes("|___: ||__: |___: ::___ :|::|"));
		System.out.println(getPossibleBarcodes("|_:_: ||_:: |___: ::_|_ :|_:|"));
		System.out.println(getPossibleBarcodes("|_|_: |__:: |___| |__:_ :___|"));
	}
	
	public static ArrayList<String> getPossibleBarcodes(String barcode) {
		// Replace null with your answer.
		return null;
	}
}