#import <iostream>

using namespace std;

void printHourglass(int n) {
    // This problem does not have a return statement. You will use cout or printf().
}

int main() {
    // See the packet for correct answers.
    printHourglass(1);
    printHourglass(2);
    printHourglass(3);
    printHourglass(5);
    printHourglass(10);
}