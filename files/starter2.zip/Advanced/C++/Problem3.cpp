#import <iostream>

using namespace std;

int getMaxValue(int roll[]) {
    // Replace 0 with your answer.
    return 0;
}

int main() {
    int values[] = {6, 2, 6, 6, 2};
    cout << getMaxValue(values) << endl; // Should be 25

    int values1[] = {1, 4, 6, 4, 1};
    cout << getMaxValue(values1) << endl; // Should be 8
    
    int values2[] = {1, 2, 4, 3, 2};
    cout << getMaxValue(values2) << endl; // Should be 30
    
    int values3[] = {1, 1, 1, 1, 1};
    cout << getMaxValue(values3) << endl; // Should be 50
    
    int values4[] = {2, 2, 5, 3, 1};
    cout << getMaxValue(values4) << endl; // Should be 5
}