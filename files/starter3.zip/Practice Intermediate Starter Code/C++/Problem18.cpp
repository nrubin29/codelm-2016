#include <iostream>

using namespace std;

int main() {
	cout << checkNumber(111999) << endl;
	cout << checkNumber(555555) << endl;
	cout << checkNumber(123452) << endl;
}
	
bool checkNumber(int n) {
	// Replace false with your answer.
	return false;
}
