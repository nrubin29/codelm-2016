#include <iostream>

using namespace std;

int main() {
	shape(1);
	shape(2);
	shape(3);
	shape(5);
}
	
void shape(int n) {
	// This problem does not have a return statement. You will use cout.
}
