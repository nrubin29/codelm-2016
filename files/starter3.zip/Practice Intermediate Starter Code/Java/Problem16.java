public class Problem16 {

	public static void main(String[] args) {
		System.out.println(encrypt("coding"));
		System.out.println(encrypt("python"));
		System.out.println(encrypt("string"));
	}
	
	public static String encrypt(String input) {
		// Replace null with your answer.
		return null;
	}
}