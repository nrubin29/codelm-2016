public class Problem17 {

	public static void main(String[] args) {
		shape(1);
		shape(2);
		shape(3);
		shape(5);
	}
	
	public static void shape(int n) {
		// This problem does not have a return statement. You will use System.out.println().
	}
}