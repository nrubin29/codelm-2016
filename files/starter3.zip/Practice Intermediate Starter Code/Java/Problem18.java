public class Problem18 {

	public static void main(String[] args) {
		System.out.println(checkNumber(111999));
		System.out.println(checkNumber(555555));
		System.out.println(checkNumber(123452));
	}
	
	public static boolean checkNumber(int n) {
		// Replace false with your answer.
		return false;
	}
}