def check_number(n):
    # Replace None with your answer.
    return None

print(check_number(111999))
print(check_number(555555))
print(check_number(123452))