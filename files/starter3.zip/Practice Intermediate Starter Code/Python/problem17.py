def shape(n):
    # Remove pass. This problem does not have a return statement. You will use print().
    pass

shape(1)
shape(2)
shape(3)
shape(5)