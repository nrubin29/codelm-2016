public class Problem5 {

	public static void main(String[] args) {
		System.out.println(isValidBarcode("|:::| ::||: |::|: :::|| ||::: :|:|:")); // Should be false
		System.out.println(isValidBarcode(":::|| :|:|: |::|: :|::| ::|:| ::||:")); // Should be false
		System.out.println(isValidBarcode("||::: |:::| :||:: :|:|: :::|| :::||")); // Should be true
	}
	
	public static boolean isValidBarcode(String barcode) {
		// Replace false with your answer.
		return false;
	}
}