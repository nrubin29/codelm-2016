public class Problem2 {

	public static void main(String[] args) {
		System.out.println(getName(2)); // Should be Ne
		System.out.println(getName(9)); // Should be New Wave
		System.out.println(getName(10)); // Should be New Wave N
		System.out.println(getName(25)); // Should be New Wave New Wave New Wav
	}
	
	public static String getName(int n) {
		// Replace null with your answer.
		return null;
	}
}