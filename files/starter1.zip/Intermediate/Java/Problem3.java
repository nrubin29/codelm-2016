public class Problem3 {

	public static void main(String[] args) {
		System.out.println(validateID(23456789)); // Should be invalid
		System.out.println(validateID(12759745)); // Should be invalid
		System.out.println(validateID(73294717)); // Should be invalid
		System.out.println(validateID(25354565)); // Should be yism
		System.out.println(validateID(25432167)); // Should be yquo
	}
	
	public static String validateID(int id) {
		// Replace null with your answer.
		return null;
	}
}