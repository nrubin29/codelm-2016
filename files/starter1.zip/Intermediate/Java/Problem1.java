public class Problem1 {

	public static void main(String[] args) {
		System.out.println(getCost(1, 1, 1, 1)); // Should be 1021.787
		System.out.println(getCost(8, 3, 4, 5)); // Should be 3721.2572
		System.out.println(getCost(10, 3, 4, 8)); // Should be 4775.8565
		System.out.println(getCost(8, 2, 10, 10)); // Should be 7811.7972
	}
	
	public static int getCost(int drives, int software, int phones, int pens) {
		// Replace 0 with your answer.
		return 0;
	}
}