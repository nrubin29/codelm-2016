public class Problem6 {

	public static void main(String[] args) {
		System.out.println(fixReport("here at New Wave, we are proud to launch our brand new wPhone 2, starting at just $500. our CEO mr. swope is very proud of our teams hard work."));
		// Should be Here at New Wave, we are proud to launch our brand new wPhone 2, starting at just E375. Our CEO Mr. Swope is very proud of our teams hard work.
		
		System.out.println(fixReport("in our last quarter, we made a profit of $340 per wPhone and $20 per software package. our stock price also grew 3.1%."));
		// Should be In our last quarter, we made a profit of E255 per wPhone and E15 per software package. Our stock price also grew 3.1%.
		
		System.out.println(fixReport("employee complaint #687517: mr. John has been acting up again. i cannot believe he makes $10000 a year. fire him. now!"));
		// Should be Employee complaint #687517: Mr. John has been acting up again. I cannot believe he makes E7500 a year. Fire him. Now!
	}
	
	public static String fixReport(String report) {
		// Replace null with your answer.
		return null;
	}
}