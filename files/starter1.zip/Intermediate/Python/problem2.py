def get_name(n):
	# Replace None with your answer.
	return None

print(get_name(2))  # Should be Ne
print(get_name(9))  # Should be New Wave
print(get_name(10))  # Should be New Wave N
print(get_name(25))  # Should be New Wave New Wave New Wav