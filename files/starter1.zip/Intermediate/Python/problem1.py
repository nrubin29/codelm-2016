def get_cost(drives, software, phones, pens):
	# Replace 0 with your answer.
	return 0

print(get_cost(1, 1, 1, 1))  # Should be 1021.787
print(get_cost(8, 3, 4, 5))  # Should be 3721.2572
print(get_cost(10, 3, 4, 8))  # Should be 4775.8565
print(get_cost(8, 2, 10, 10))  # Should be 7811.7972