def is_valid_barcode(barcode):
	# Replace False with your answer.
	return False

print(is_valid_barcode("|:::| ::||: |::|: :::|| ||::: :|:|:"))  # Should be False
print(is_valid_barcode(":::|| :|:|: |::|: :|::| ::|:| ::||:"))  # Should be False
print(is_valid_barcode("||::: |:::| :||:: :|:|: :::|| :::||"))  # Should be True