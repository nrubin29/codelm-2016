#import <iostream>

using namespace std;

string validateBarcode(int id) {
    // Replace NULL with your answer.
    return NULL;
}

int main() {
    cout << validateBarcode(23456789) << endl; // Should be invalid
    cout << validateBarcode(12759745) << endl; // Should be invalid
    cout << validateBarcode(73294717) << endl; // Should be invalid
    cout << validateBarcode(25354565) << endl; // Should be yism
    cout << validateBarcode(25432167) << endl; // Should be yquo
}