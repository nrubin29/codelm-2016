#import <iostream>

using namespace std;

int getCost(int drives, int software, int phones, int pens) {
    // Replace 0 with your answer.
    return 0;
}

int main() {
	cout << getCost(1, 1, 1, 1) << endl; // Should be 1021.787
	cout << getCost(8, 3, 4, 5) << endl; // Should be 3721.2572
	cout << getCost(10, 3, 4, 8) << endl; // Should be 4775.8565
	cout << getCost(8, 2, 10, 10) << endl; // Should be 7811.7972
}