#import <iostream>

using namespace std;

bool isValidBarcode(string barcode) {
    // Replace false with your answer.
    return false;
}

int main() {
    cout << isValidBarcode("|:::| ::||: |::|: :::|| ||::: :|:|:") << endl; // Should be false
    cout << isValidBarcode(":::|| :|:|: |::|: :|::| ::|:| ::||:") << endl; // Should be false
    cout << isValidBarcode("||::: |:::| :||:: :|:|: :::|| :::||") << endl; // Should be true
}