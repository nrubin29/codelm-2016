#import <iostream>

using namespace std;

string getName(int n) {
    // Replace NULL with your answer.
    return NULL;
}

int main() {
    cout << getName(2) << endl; // Should be Ne
    cout << getName(9) << endl; // Should be New Wave
    cout << getName(10) << endl; // Should be New Wave N
    cout << getName(25) << endl; // Should be New Wave New Wave New Wav
}