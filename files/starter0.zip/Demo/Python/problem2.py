def greet(name):
	# Replace None with your answer.
	return None

print(greet("Noah"))  # Should be Hello, Noah!
print(greet("Dog"))  # Should be Hello, Dog!