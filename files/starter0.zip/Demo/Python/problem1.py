def is_even(n):
	# Replace False with your answer.
	return False

print(isEven(0))  # Should be True
print(isEven(1))  # Should be False
print(isEven(2))  # Should be True