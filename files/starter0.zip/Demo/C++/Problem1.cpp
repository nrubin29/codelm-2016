#import <iostream>

using namespace std;

bool isEven(int n) {
    // Replace false with your answer.
    return false;
}

int main() {
    cout << isEven(0) << endl; // Should be true
    cout << isEven(1) << endl; // Should be false
    cout << isEven(2) << endl; // Should be true
}