#import <iostream>

using namespace std;

string greet(string name) {
    // Replace NULL with your answer.
    return NULL;
}

int main() {
    cout << greet("Noah") << endl; // Should be Hello, Noah!
    cout << greet("Dog") << endl; // Should be Hello, Dog!
}