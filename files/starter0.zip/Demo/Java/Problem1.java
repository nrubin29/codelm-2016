public class Problem1 {

	public static void main(String[] args) {
		System.out.println(isEven(0)); // Should be true
		System.out.println(isEven(1)); // Should be false
		System.out.println(isEven(2)); // Should be true
	}
	
	public static boolean isEven(int n) {
		// Replace false with your answer.
		return false;
	}
}