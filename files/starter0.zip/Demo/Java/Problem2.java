public class Problem2 {

	public static void main(String[] args) {
		System.out.println(greet("Noah")); // Should be Hello, Noah!
		System.out.println(greet("Dog")); // Should be Hello, Dog!
	}
	
	public static String greet(String name) {
		// Replace null with your answer.
		return null;
	}
}